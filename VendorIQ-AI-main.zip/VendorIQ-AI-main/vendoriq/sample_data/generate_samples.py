"""
generate_samples.py
--------------------
Run this once to create 3 sample vendor proposal PDFs in sample_data/
so you can demo VendorIQ AI immediately without sourcing real proposals.

Usage:
    python sample_data/generate_samples.py
"""

import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.units import cm

OUT_DIR = os.path.dirname(os.path.abspath(__file__))

SAMPLE_PROPOSALS = {
    "vendor_apex_systems.pdf": """
Apex Systems Solutions - Vendor Proposal

Vendor: Apex Systems Solutions Pvt Ltd
Total Cost: $52,000 for the full implementation package.
Delivery Timeline: Estimated 45 days from purchase order confirmation.
Warranty Period: 24 months comprehensive warranty on all hardware components.
Support Details: 24/7 dedicated support line with 4-hour SLA response time and an onsite engineer available on request.
Payment Terms: 30% advance, 40% on delivery, 30% after 30-day acceptance period.
Key Features: Cloud dashboard, real-time analytics, API integration, automated reporting, mobile app access, role-based access control.
Risks Mentioned: Pricing subject to a 5% increase if raw material costs rise beyond Q3 2026. Warranty excludes third-party integrations.
""",
    "vendor_bluewave_tech.pdf": """
BlueWave Technologies - Commercial Proposal

Vendor: BlueWave Technologies
Total Cost: $38,500 total contract value including installation.
Delivery Timeline: 60 days, subject to component availability.
Warranty Period: 12 months standard warranty; extended warranty available at extra cost.
Support Details: Business hours email support only, response time not guaranteed in this proposal.
Payment Terms: 50% upfront, 50% due within 15 days of delivery.
Key Features: Basic dashboard, monthly reporting, email alerts, single sign-on.
Risks Mentioned: No penalty clause for late delivery. Limited scalability beyond 500 users without a separate upgrade contract.
""",
    "vendor_crestpoint_group.pdf": """
Crestpoint Group - Enterprise Proposal

Vendor: Crestpoint Group
Total Cost: $61,750 all-inclusive, covering hardware, software, and training.
Delivery Timeline: 30 days guaranteed with penalty clause for delays.
Warranty Period: 36 months full-coverage warranty including labor.
Support Details: Dedicated account manager, 24/7 priority support, quarterly business reviews included.
Payment Terms: Milestone-based payments across 4 project phases, no large upfront payment required.
Key Features: Advanced analytics suite, AI-powered forecasting, API integration, mobile app, custom reporting, dedicated training program, multi-region deployment.
Risks Mentioned: Premium pricing tier; requires a minimum 2-year contract commitment.
""",
}


def generate():
    styles = getSampleStyleSheet()
    for filename, content in SAMPLE_PROPOSALS.items():
        path = os.path.join(OUT_DIR, filename)
        doc = SimpleDocTemplate(path, pagesize=A4, topMargin=2 * cm, bottomMargin=2 * cm)
        story = []
        for line in content.strip().split("\n"):
            line = line.strip()
            if not line:
                story.append(Spacer(1, 8))
                continue
            story.append(Paragraph(line, styles["Normal"]))
            story.append(Spacer(1, 6))
        doc.build(story)
        print(f"Created {path}")


if __name__ == "__main__":
    generate()
