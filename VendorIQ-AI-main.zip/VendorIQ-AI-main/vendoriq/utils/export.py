"""
export.py
---------
Generates downloadable artifacts:
    - CSV summary of the vendor comparison table
    - PDF comparison/executive report (via reportlab, no external binaries needed)
"""

import io
import pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import (
    SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak
)


def build_comparison_dataframe(vendors: list) -> pd.DataFrame:
    rows = []
    for v in vendors:
        rows.append({
            "Vendor": v.get("vendor_name", ""),
            "Total Cost": v.get("total_cost", ""),
            "Delivery Timeline": v.get("delivery_timeline", ""),
            "Warranty": v.get("warranty_period", ""),
            "Support": v.get("support_details", ""),
            "Payment Terms": v.get("payment_terms", ""),
            "Key Features": ", ".join(v.get("key_features", [])[:5]),
            "Risk Level": v.get("overall_risk_level", "Low"),
            "Overall Score": v.get("overall_score", 0),
        })
    return pd.DataFrame(rows)


def dataframe_to_csv_bytes(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False).encode("utf-8")


def build_pdf_report(vendors: list, recommendation: dict, summary: dict, health: dict) -> bytes:
    """Builds a polished procurement comparison PDF report and returns raw bytes."""
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=A4,
        topMargin=1.5 * cm, bottomMargin=1.5 * cm,
        leftMargin=1.5 * cm, rightMargin=1.5 * cm,
    )
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("TitleStyle", parent=styles["Title"], textColor=colors.HexColor("#1F3C88"))
    h2_style = ParagraphStyle("H2Style", parent=styles["Heading2"], textColor=colors.HexColor("#1F3C88"), spaceBefore=14)
    body_style = ParagraphStyle("BodyStyle", parent=styles["BodyText"], leading=15)

    story = []

    # --- Cover / Title ---
    story.append(Paragraph("VendorIQ AI — Procurement Comparison Report", title_style))
    story.append(Spacer(1, 6))
    story.append(Paragraph("Automated AI-generated vendor proposal analysis.", styles["Normal"]))
    story.append(Spacer(1, 16))

    # --- Procurement Health Score ---
    story.append(Paragraph("Procurement Health Score", h2_style))
    story.append(Paragraph(f"{health.get('score', 'N/A')} / 100 — {health.get('label', '')}", body_style))
    story.append(Spacer(1, 10))

    # --- Comparison Table ---
    story.append(Paragraph("Vendor Comparison Table", h2_style))
    df = build_comparison_dataframe(vendors)
    table_data = [list(df.columns)] + df.astype(str).values.tolist()

    # Wrap long text cells in Paragraphs so the table doesn't overflow the page
    wrapped_data = []
    for r_idx, row in enumerate(table_data):
        wrapped_row = []
        for cell in row:
            style = styles["Heading5"] if r_idx == 0 else styles["BodyText"]
            wrapped_row.append(Paragraph(str(cell), style))
        wrapped_data.append(wrapped_row)

    col_count = len(df.columns)
    page_width = A4[0] - 3 * cm
    col_widths = [page_width / col_count] * col_count

    table = Table(wrapped_data, colWidths=col_widths, repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F3C88")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#CCCCCC")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F3F6FC")]),
    ]))
    story.append(table)
    story.append(Spacer(1, 16))

    # --- Recommendation ---
    if recommendation:
        story.append(Paragraph("AI Recommendation", h2_style))
        story.append(Paragraph(
            f"<b>Recommended Vendor:</b> {recommendation.get('recommended_vendor', 'N/A')} "
            f"(Confidence: {recommendation.get('confidence_score', 'N/A')}%)",
            body_style,
        ))
        story.append(Paragraph(recommendation.get("reasoning", ""), body_style))
        trade_offs = recommendation.get("trade_offs", [])
        if trade_offs:
            story.append(Paragraph("<b>Trade-offs:</b> " + "; ".join(trade_offs), body_style))
        story.append(Spacer(1, 10))

    # --- Executive Summary ---
    if summary:
        story.append(Paragraph("Executive Summary", h2_style))
        story.append(Paragraph(summary.get("overview", ""), body_style))
        strengths = summary.get("strengths_by_vendor", {})
        weaknesses = summary.get("weaknesses_by_vendor", {})
        for vendor_name in strengths.keys():
            story.append(Paragraph(f"<b>{vendor_name}</b>", body_style))
            story.append(Paragraph(f"Strength: {strengths.get(vendor_name, '')}", body_style))
            story.append(Paragraph(f"Weakness: {weaknesses.get(vendor_name, '')}", body_style))
            story.append(Spacer(1, 4))
        story.append(Spacer(1, 6))
        story.append(Paragraph("<b>Final Recommendation:</b> " + summary.get("final_recommendation", ""), body_style))

    doc.build(story)
    buffer.seek(0)
    return buffer.read()
