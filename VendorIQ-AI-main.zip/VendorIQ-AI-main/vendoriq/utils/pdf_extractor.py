"""
pdf_extractor.py
----------------
Handles extraction of raw text from uploaded vendor proposal PDFs.

Strategy:
1. Try pdfplumber first (better layout/table handling).
2. If pdfplumber fails or returns near-empty text, fall back to PyPDF2.
3. Never raise to the caller - always return a result dict with an
   'error' key so the UI can show a friendly warning instead of crashing.
"""

import io
import pdfplumber
import PyPDF2


def _extract_with_pdfplumber(file_bytes: bytes) -> str:
    text_chunks = []
    with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text() or ""
            text_chunks.append(page_text)
    return "\n".join(text_chunks).strip()


def _extract_with_pypdf2(file_bytes: bytes) -> str:
    text_chunks = []
    reader = PyPDF2.PdfReader(io.BytesIO(file_bytes))
    for page in reader.pages:
        text_chunks.append(page.extract_text() or "")
    return "\n".join(text_chunks).strip()


def extract_text_from_pdf(uploaded_file) -> dict:
    """
    Extract raw text from a Streamlit UploadedFile object.

    Returns:
        {
            "filename": str,
            "text": str,
            "pages": int,
            "method": "pdfplumber" | "pypdf2" | "failed",
            "error": str | None
        }
    """
    filename = getattr(uploaded_file, "name", "unknown.pdf")
    result = {"filename": filename, "text": "", "pages": 0, "method": None, "error": None}

    try:
        file_bytes = uploaded_file.read()
        # Reset pointer in case the same file object is reused elsewhere
        try:
            uploaded_file.seek(0)
        except Exception:
            pass

        # Attempt 1: pdfplumber
        try:
            text = _extract_with_pdfplumber(file_bytes)
            if text and len(text.strip()) > 20:
                result["text"] = text
                result["method"] = "pdfplumber"
                with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
                    result["pages"] = len(pdf.pages)
                return result
        except Exception:
            pass  # fall through to PyPDF2

        # Attempt 2: PyPDF2 fallback
        try:
            text = _extract_with_pypdf2(file_bytes)
            reader = PyPDF2.PdfReader(io.BytesIO(file_bytes))
            result["pages"] = len(reader.pages)
            if text and len(text.strip()) > 0:
                result["text"] = text
                result["method"] = "pypdf2"
                return result
        except Exception as e2:
            result["error"] = f"PyPDF2 fallback also failed: {e2}"
            result["method"] = "failed"
            return result

        # Both succeeded technically but produced no text (likely scanned/image PDF)
        result["error"] = "No extractable text found (file may be a scanned image PDF)."
        result["method"] = "failed"
        return result

    except Exception as e:
        result["error"] = f"Could not read file: {e}"
        result["method"] = "failed"
        return result


def extract_all(uploaded_files: list) -> list:
    """Run extract_text_from_pdf across a list of uploaded files."""
    return [extract_text_from_pdf(f) for f in uploaded_files]
