"""
charts.py
---------
All Plotly figure builders for VendorIQ AI. Kept separate from app.py so the
dashboard file stays focused on layout/flow.
"""

import plotly.graph_objects as go
import plotly.express as px

BRAND_COLORS = ["#4F8BFF", "#7CDBB5", "#FFB84F", "#FF6B6B", "#B78BFF"]

CRITERIA_LABELS = {
    "cost_efficiency": "Cost Efficiency",
    "delivery_speed": "Delivery Speed",
    "feature_coverage": "Feature Coverage",
    "warranty_strength": "Warranty Strength",
    "support_quality": "Support Quality",
    "risk_score": "Risk Score",
}


def _base_layout(fig, title, theme="dark"):
    bg = "rgba(0,0,0,0)"
    font_color = "#E6E6E6" if theme == "dark" else "#1A1A1A"
    fig.update_layout(
        title=title,
        paper_bgcolor=bg,
        plot_bgcolor=bg,
        font=dict(color=font_color, family="Inter, sans-serif"),
        legend=dict(orientation="h", yanchor="bottom", y=-0.25, xanchor="center", x=0.5),
        margin=dict(t=60, b=40, l=40, r=40),
    )
    return fig


def radar_chart(vendors: list, theme="dark"):
    fig = go.Figure()
    categories = list(CRITERIA_LABELS.values())
    for i, v in enumerate(vendors):
        scores = v.get("scores", {})
        values = [scores.get(k, 0) for k in CRITERIA_LABELS.keys()]
        values.append(values[0])  # close the loop
        fig.add_trace(go.Scatterpolar(
            r=values,
            theta=categories + [categories[0]],
            fill="toself",
            name=v.get("vendor_name", f"Vendor {i+1}"),
            line=dict(color=BRAND_COLORS[i % len(BRAND_COLORS)]),
        ))
    fig.update_layout(
        polar=dict(
            radialaxis=dict(visible=True, range=[0, 100]),
            bgcolor="rgba(0,0,0,0)",
        ),
        showlegend=True,
    )
    return _base_layout(fig, "Vendor Capability Radar", theme)


def score_bar_chart(vendors: list, theme="dark"):
    names = [v.get("vendor_name") for v in vendors]
    scores = [v.get("overall_score", 0) for v in vendors]
    fig = go.Figure(go.Bar(
        x=names, y=scores,
        marker_color=BRAND_COLORS[:len(names)],
        text=[f"{s:.1f}" for s in scores],
        textposition="outside",
    ))
    fig.update_yaxes(range=[0, 110], title="Overall Score (/100)")
    return _base_layout(fig, "Vendor Overall Scores", theme)


def ranking_chart(vendors: list, theme="dark"):
    ranked = sorted(vendors, key=lambda v: v.get("overall_score", 0))
    names = [v.get("vendor_name") for v in ranked]
    scores = [v.get("overall_score", 0) for v in ranked]
    fig = go.Figure(go.Bar(
        x=scores, y=names, orientation="h",
        marker_color=BRAND_COLORS[:len(names)],
        text=[f"{s:.1f}" for s in scores],
        textposition="outside",
    ))
    fig.update_xaxes(range=[0, 110], title="Overall Score (/100)")
    return _base_layout(fig, "Vendor Ranking Leaderboard", theme)


def cost_comparison_chart(vendors: list, theme="dark"):
    names = [v.get("vendor_name") for v in vendors]
    costs = [v.get("total_cost_numeric", 0) for v in vendors]
    fig = go.Figure(go.Bar(
        x=names, y=costs,
        marker_color=BRAND_COLORS[:len(names)],
        text=[f"${c:,.0f}" for c in costs],
        textposition="outside",
    ))
    fig.update_yaxes(title="Total Cost (USD)")
    return _base_layout(fig, "Cost Comparison Across Vendors", theme)


def risk_severity_chart(risk_by_vendor: dict, theme="dark"):
    severity_order = ["Low", "Medium", "High"]
    counts = {s: 0 for s in severity_order}
    for info in risk_by_vendor.values():
        for r in info.get("risks", []):
            sev = r.get("severity", "Low")
            counts[sev] = counts.get(sev, 0) + 1
    colors = {"Low": "#7CDBB5", "Medium": "#FFB84F", "High": "#FF6B6B"}
    fig = go.Figure(go.Bar(
        x=severity_order,
        y=[counts[s] for s in severity_order],
        marker_color=[colors[s] for s in severity_order],
        text=[counts[s] for s in severity_order],
        textposition="outside",
    ))
    fig.update_yaxes(title="Number of Risks Flagged")
    return _base_layout(fig, "Risk Distribution Across Vendor Pool", theme)
