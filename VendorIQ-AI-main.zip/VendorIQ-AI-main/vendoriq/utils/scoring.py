"""
scoring.py
----------
Computes the VendorIQ composite score (0-100) for each vendor across:
    Cost Efficiency, Delivery Speed, Feature Coverage,
    Warranty Strength, Support Quality, Risk Score

All sub-scores are normalized 0-100 relative to the vendor pool, then
combined with the weights below. This keeps scoring stable regardless
of currency/units used in the raw proposals.
"""

WEIGHTS = {
    "cost_efficiency": 0.25,
    "delivery_speed": 0.15,
    "feature_coverage": 0.20,
    "warranty_strength": 0.15,
    "support_quality": 0.10,
    "risk_score": 0.15,
}

SEVERITY_PENALTY = {"Low": 5, "Medium": 15, "High": 30}


def _normalize(value, min_v, max_v, invert=False):
    """Scale value into 0-100 given pool min/max. invert=True means lower raw value = higher score."""
    if max_v == min_v:
        return 75.0  # neutral score when there's no variance to compare
    pct = (value - min_v) / (max_v - min_v)
    if invert:
        pct = 1 - pct
    return round(max(0, min(100, pct * 100)), 1)


def _support_quality_score(support_text: str) -> float:
    """Crude heuristic: longer, more specific support descriptions score higher."""
    if not support_text or "not specified" in support_text.lower():
        return 40.0
    length_score = min(100, len(support_text) / 2)
    keyword_bonus = sum(
        10 for kw in ["24/7", "onsite", "dedicated", "sla", "response time", "priority"]
        if kw in support_text.lower()
    )
    return round(min(100, 50 + keyword_bonus + length_score / 4), 1)


def _feature_coverage_score(features: list, max_features_in_pool: int) -> float:
    if not features or max_features_in_pool == 0:
        return 40.0
    return round(min(100, (len(features) / max_features_in_pool) * 100), 1)


def compute_scores(vendors: list, risk_by_vendor: dict) -> list:
    """
    vendors: list of extracted vendor dicts
    risk_by_vendor: {vendor_name: risk_detection_result_dict}

    Returns the same vendor list with a "scores" sub-dict and "overall_score" added.
    """
    if not vendors:
        return []

    costs = [v.get("total_cost_numeric") or 0 for v in vendors]
    deliveries = [v.get("delivery_days_numeric") or 0 for v in vendors]
    warranties = [v.get("warranty_months_numeric") or 0 for v in vendors]
    max_features = max((len(v.get("key_features", [])) for v in vendors), default=0)

    valid_costs = [c for c in costs if c > 0] or [0]
    valid_deliveries = [d for d in deliveries if d > 0] or [0]
    valid_warranties = [w for w in warranties if w > 0] or [0]

    for v in vendors:
        cost = v.get("total_cost_numeric") or max(valid_costs)
        delivery = v.get("delivery_days_numeric") or max(valid_deliveries)
        warranty = v.get("warranty_months_numeric") or min(valid_warranties)

        cost_score = _normalize(cost, min(valid_costs), max(valid_costs), invert=True)
        delivery_score = _normalize(delivery, min(valid_deliveries), max(valid_deliveries), invert=True)
        warranty_score = _normalize(warranty, min(valid_warranties), max(valid_warranties), invert=False)
        feature_score = _feature_coverage_score(v.get("key_features", []), max_features)
        support_score = _support_quality_score(v.get("support_details", ""))

        risk_info = risk_by_vendor.get(v["vendor_name"], {})
        risk_penalty = sum(
            SEVERITY_PENALTY.get(r.get("severity", "Low"), 5)
            for r in risk_info.get("risks", [])
        )
        risk_score = round(max(0, 100 - risk_penalty), 1)

        sub_scores = {
            "cost_efficiency": cost_score,
            "delivery_speed": delivery_score,
            "feature_coverage": feature_score,
            "warranty_strength": warranty_score,
            "support_quality": support_score,
            "risk_score": risk_score,
        }

        overall = round(sum(sub_scores[k] * WEIGHTS[k] for k in WEIGHTS), 1)

        v["scores"] = sub_scores
        v["overall_score"] = overall
        v["overall_risk_level"] = risk_info.get("overall_risk_level", "Low")

    return sorted(vendors, key=lambda x: x["overall_score"], reverse=True)


def procurement_health_score(vendors: list) -> dict:
    """
    Hackathon differentiator: an aggregate 'Procurement Health Score' reflecting
    how competitive and low-risk the overall vendor pool is (not just one vendor).
    """
    if not vendors:
        return {"score": 0, "label": "No Data"}

    avg_overall = sum(v["overall_score"] for v in vendors) / len(vendors)
    spread = max(v["overall_score"] for v in vendors) - min(v["overall_score"] for v in vendors)
    # Wider spread (more differentiated competitive field) is good for buyer leverage
    competitiveness_bonus = min(15, spread / 4)
    score = round(min(100, avg_overall * 0.85 + competitiveness_bonus), 1)

    if score >= 80:
        label = "Excellent"
    elif score >= 65:
        label = "Healthy"
    elif score >= 45:
        label = "Needs Attention"
    else:
        label = "At Risk"

    return {"score": score, "label": label}


def best_value_badge(vendors: list) -> str:
    """Returns the vendor name with the best cost-efficiency-to-overall-score ratio."""
    if not vendors:
        return ""
    scored = [v for v in vendors if v.get("scores")]
    if not scored:
        return ""
    best = max(scored, key=lambda v: (v["scores"]["cost_efficiency"] * 0.5 + v["overall_score"] * 0.5))
    return best["vendor_name"]
