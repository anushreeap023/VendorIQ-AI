"""
gemini_client.py
-----------------
All Gemini API interactions for VendorIQ AI live here.

Design notes:
- Every public function returns a plain Python dict/list so the rest of
  the app never has to deal with raw model text.
- If no API key is configured, or a call fails for any reason, functions
  fall back to a lightweight rule-based/demo response instead of crashing
  the app. This keeps the product demoable even without live credentials.
- We ask Gemini to respond in strict JSON and defensively parse the
  response (stripping markdown code fences, catching JSONDecodeError).
"""

import json
import re
import streamlit as st

try:
    from google import genai as genai_sdk
    from google.genai import types as genai_types
    GENAI_AVAILABLE = True
except ImportError:
    GENAI_AVAILABLE = False

MODEL_NAME = "gemini-2.5-flash"


def _get_client(api_key: str):
    """Build a google-genai Client for this API key. Returns None if unusable."""
    if not GENAI_AVAILABLE or not api_key:
        return None
    try:
        return genai_sdk.Client(api_key=api_key)
    except Exception:
        return None


def _clean_json_text(raw: str) -> str:
    """Strip ```json ... ``` fences and any leading/trailing chatter."""
    raw = raw.strip()
    raw = re.sub(r"^```(json)?", "", raw, flags=re.IGNORECASE).strip()
    raw = re.sub(r"```$", "", raw).strip()
    # Grab the outermost JSON object/array if extra text slipped in
    match = re.search(r"(\{.*\}|\[.*\])", raw, flags=re.DOTALL)
    return match.group(1) if match else raw


def _call_gemini_json(prompt: str, api_key: str):
    """Call Gemini and parse JSON response. Returns None on any failure."""
    client = _get_client(api_key)
    if client is None:
        return None
    try:
        response = client.models.generate_content(
            model=MODEL_NAME,
            contents=prompt,
            config=genai_types.GenerateContentConfig(
                temperature=0.2,
                max_output_tokens=2048,
            ),
        )
        cleaned = _clean_json_text(response.text)
        return json.loads(cleaned)
    except Exception as e:
        st.session_state.setdefault("gemini_errors", []).append(str(e))
        return None


# --------------------------------------------------------------------------
# 1. STRUCTURED DATA EXTRACTION
# --------------------------------------------------------------------------

EXTRACTION_PROMPT = """You are a senior procurement analyst AI. Read the vendor proposal text
below and extract structured information. Respond with ONLY a valid JSON object
(no markdown, no commentary) using exactly this schema:

{{
  "vendor_name": "string",
  "total_cost": "string (include currency and figure, e.g. '$45,000')",
  "total_cost_numeric": number (best-guess numeric USD value, 0 if unknown),
  "delivery_timeline": "string (e.g. '6 weeks')",
  "delivery_days_numeric": number (best-guess in days, 0 if unknown),
  "warranty_period": "string (e.g. '2 years')",
  "warranty_months_numeric": number (best-guess in months, 0 if unknown),
  "support_details": "string, 1-2 sentences",
  "payment_terms": "string, 1-2 sentences",
  "key_features": ["string", "string", "..."],
  "risks_mentioned": ["string", "string", "..."]
}}

Proposal text:
\"\"\"
{proposal_text}
\"\"\"
"""


def _demo_extract(text: str, filename: str) -> dict:
    """Rule-based fallback extraction used when Gemini is unavailable."""
    def find(pattern, default="Not specified"):
        m = re.search(pattern, text, re.IGNORECASE)
        return m.group(0) if m else default

    cost_match = re.search(r"\$[\d,]+(\.\d{2})?", text)
    cost = cost_match.group(0) if cost_match else "Not specified"
    cost_num = float(cost.replace("$", "").replace(",", "")) if cost_match else 0

    delivery = find(r"\d+\s*(days|weeks|months)")
    warranty = find(r"\d+\s*(year|month)s?\s*warranty") or find(r"warranty[^.\n]{0,40}")

    vendor_name = filename.rsplit(".", 1)[0].replace("_", " ").title()

    return {
        "vendor_name": vendor_name,
        "total_cost": cost,
        "total_cost_numeric": cost_num,
        "delivery_timeline": delivery,
        "delivery_days_numeric": 0,
        "warranty_period": warranty,
        "warranty_months_numeric": 0,
        "support_details": "Not specified (offline demo mode - connect Gemini API for full extraction)",
        "payment_terms": "Not specified (offline demo mode)",
        "key_features": ["Feature extraction requires Gemini API key"],
        "risks_mentioned": ["Automatic risk detection requires Gemini API key"],
        "_demo_mode": True,
    }


def extract_vendor_data(proposal_text: str, filename: str, api_key: str) -> dict:
    """Extract structured vendor fields from raw proposal text."""
    if not proposal_text or len(proposal_text.strip()) < 10:
        data = _demo_extract("", filename)
        data["vendor_name"] = filename.rsplit(".", 1)[0].replace("_", " ").title()
        data["support_details"] = "No readable text found in this PDF."
        return data

    prompt = EXTRACTION_PROMPT.format(proposal_text=proposal_text[:12000])
    result = _call_gemini_json(prompt, api_key)

    if result is None:
        return _demo_extract(proposal_text, filename)

    # Fill any missing keys defensively
    defaults = _demo_extract(proposal_text, filename)
    for k, v in defaults.items():
        result.setdefault(k, v)
    result["_demo_mode"] = False
    result["source_file"] = filename
    return result


# --------------------------------------------------------------------------
# 2. AI RECOMMENDATION ENGINE
# --------------------------------------------------------------------------

RECOMMENDATION_PROMPT = """You are a procurement decision advisor. Given the following vendor
comparison data (JSON array), recommend the single best vendor for the buyer.
Respond with ONLY valid JSON in this schema:

{{
  "recommended_vendor": "string - exact vendor name from the data",
  "confidence_score": number (0-100),
  "reasoning": "2-4 sentence explanation of why this vendor was selected",
  "trade_offs": ["string", "string", "..."],
  "runner_up": "string - name of second best vendor"
}}

Vendor data:
{vendor_json}
"""


def generate_recommendation(vendors: list, api_key: str) -> dict:
    if not vendors:
        return {}
    prompt = RECOMMENDATION_PROMPT.format(vendor_json=json.dumps(vendors, indent=2)[:10000])
    result = _call_gemini_json(prompt, api_key)
    if result is None:
        # Fallback: pick lowest total_cost_numeric as naive demo recommendation
        ranked = sorted(vendors, key=lambda v: v.get("total_cost_numeric") or 9e18)
        best = ranked[0]["vendor_name"] if ranked else "N/A"
        runner = ranked[1]["vendor_name"] if len(ranked) > 1 else "N/A"
        return {
            "recommended_vendor": best,
            "confidence_score": 55,
            "reasoning": "Demo-mode heuristic: lowest quoted total cost among submitted proposals. Connect a Gemini API key for full qualitative analysis of features, risk, and support quality.",
            "trade_offs": ["Recommendation based on cost only in offline demo mode."],
            "runner_up": runner,
        }
    return result


# --------------------------------------------------------------------------
# 3. RISK DETECTION
# --------------------------------------------------------------------------

RISK_PROMPT = """You are a contract risk analyst. Review this vendor's extracted proposal data
(JSON) and identify procurement risks. Respond with ONLY valid JSON:

{{
  "risks": [
    {{
      "category": "Missing Information | Hidden Risk | Unclear Terms | Expensive Pricing | Weak Support",
      "description": "string, 1 sentence",
      "severity": "Low | Medium | High"
    }}
  ],
  "overall_risk_level": "Low | Medium | High"
}}

Vendor data:
{vendor_json}
"""


def detect_risks(vendor: dict, api_key: str) -> dict:
    prompt = RISK_PROMPT.format(vendor_json=json.dumps(vendor, indent=2)[:6000])
    result = _call_gemini_json(prompt, api_key)
    if result is None:
        risks = []
        if not vendor.get("total_cost_numeric"):
            risks.append({"category": "Missing Information", "description": "Total cost could not be confirmed.", "severity": "Medium"})
        if "not specified" in str(vendor.get("warranty_period", "")).lower():
            risks.append({"category": "Unclear Terms", "description": "Warranty period is not clearly stated.", "severity": "Medium"})
        if "not specified" in str(vendor.get("support_details", "")).lower():
            risks.append({"category": "Weak Support", "description": "Support commitments are unclear or missing.", "severity": "High"})
        if not risks:
            risks.append({"category": "Missing Information", "description": "Limited analysis available in offline demo mode.", "severity": "Low"})
        overall = "High" if any(r["severity"] == "High" for r in risks) else ("Medium" if risks else "Low")
        return {"risks": risks, "overall_risk_level": overall}
    return result


# --------------------------------------------------------------------------
# 4. EXECUTIVE SUMMARY
# --------------------------------------------------------------------------

SUMMARY_PROMPT = """You are drafting an executive procurement report. Based on the vendor
comparison data below (JSON array), write a concise executive summary. Respond with ONLY
valid JSON:

{{
  "overview": "2-3 sentence overview of the vendor pool and evaluation context",
  "strengths_by_vendor": {{"vendor name": "1 sentence strength summary", "...": "..."}},
  "weaknesses_by_vendor": {{"vendor name": "1 sentence weakness summary", "...": "..."}},
  "final_recommendation": "2-3 sentence final recommendation paragraph"
}}

Vendor data:
{vendor_json}
"""


def generate_executive_summary(vendors: list, api_key: str) -> dict:
    if not vendors:
        return {}
    prompt = SUMMARY_PROMPT.format(vendor_json=json.dumps(vendors, indent=2)[:10000])
    result = _call_gemini_json(prompt, api_key)
    if result is None:
        names = [v.get("vendor_name", "Vendor") for v in vendors]
        return {
            "overview": f"{len(vendors)} vendor proposal(s) were analyzed: {', '.join(names)}. Full AI narrative analysis requires a connected Gemini API key.",
            "strengths_by_vendor": {n: "Not analyzed (offline demo mode)" for n in names},
            "weaknesses_by_vendor": {n: "Not analyzed (offline demo mode)" for n in names},
            "final_recommendation": "Connect a Gemini API key in the sidebar to generate a full AI-written executive summary and recommendation.",
        }
    return result


# --------------------------------------------------------------------------
# 5. NEGOTIATION SUGGESTIONS (hackathon differentiator feature)
# --------------------------------------------------------------------------

NEGOTIATION_PROMPT = """You are a procurement negotiation strategist. Based on this vendor's
data (JSON) compared against the average of all vendors in the pool (also provided),
suggest concrete negotiation talking points. Respond with ONLY valid JSON:

{{
  "negotiation_points": ["string", "string", "..."],
  "estimated_savings_pct": number (0-100, realistic estimated % cost reduction achievable),
  "estimated_savings_amount": "string, e.g. '$3,200'"
}}

Vendor data:
{vendor_json}

Pool averages:
{pool_json}
"""


def generate_negotiation_suggestions(vendor: dict, pool_avg: dict, api_key: str) -> dict:
    prompt = NEGOTIATION_PROMPT.format(
        vendor_json=json.dumps(vendor, indent=2)[:6000],
        pool_json=json.dumps(pool_avg, indent=2)[:2000],
    )
    result = _call_gemini_json(prompt, api_key)
    if result is None:
        cost = vendor.get("total_cost_numeric") or 0
        avg_cost = pool_avg.get("avg_cost", cost) or cost
        if cost > avg_cost and avg_cost > 0:
            savings_pct = round(min(15, ((cost - avg_cost) / cost) * 100), 1)
        else:
            savings_pct = 5.0
        savings_amount = round((savings_pct / 100) * cost, 2) if cost else 0
        return {
            "negotiation_points": [
                "Benchmark this quote against pool average and request a price match.",
                "Ask for extended warranty at no extra cost given competitor terms.",
                "Request milestone-based payment terms to reduce upfront risk.",
            ],
            "estimated_savings_pct": savings_pct,
            "estimated_savings_amount": f"${savings_amount:,.0f}" if savings_amount else "N/A",
        }
    return result
